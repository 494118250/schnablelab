f <- function(N) {
    for (i in 1:N) {
        for (j in 1:N) {
            for (k in 1:N) {
                i + j + k
            }
        }
    }
}

