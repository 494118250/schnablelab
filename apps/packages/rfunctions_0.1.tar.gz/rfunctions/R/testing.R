



crossprodeig <- function(x)
{
  .Call("crossprodeig", X = x, PACKAGE = "rfunctions")
}